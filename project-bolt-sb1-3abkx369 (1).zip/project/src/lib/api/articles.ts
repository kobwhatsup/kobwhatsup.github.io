import articlesData from '../data/articles.json';
import type { Article } from '../types';

export async function getLatestArticles(limit = 3): Promise<Article[]> {
  return articlesData.articles
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, limit);
}

export async function getArticlesByCategory(category: string): Promise<Article[]> {
  return articlesData.articles
    .filter(article => article.category === category)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

export async function getArticleById(id: string): Promise<Article | null> {
  return articlesData.articles.find(article => article.id === id) || null;
}