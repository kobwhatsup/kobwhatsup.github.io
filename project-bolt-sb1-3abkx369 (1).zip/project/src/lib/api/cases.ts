import casesData from '../data/cases.json';
import type { Case } from '../types';

export async function getLatestCases(limit = 3): Promise<Case[]> {
  return casesData.cases
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, limit);
}

export async function getCasesByCategory(category: string): Promise<Case[]> {
  return casesData.cases
    .filter(case_ => case_.category === category)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

export async function getCaseById(id: string): Promise<Case | null> {
  return casesData.cases.find(case_ => case_.id === id) || null;
}