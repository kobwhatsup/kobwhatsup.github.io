import coursesData from '../data/courses.json';
import type { Course } from '../types';

export async function getLatestCourses(limit = 3): Promise<Course[]> {
  return coursesData.courses
    .sort((a, b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime())
    .slice(0, limit);
}

export async function getCoursesByCategory(category: string): Promise<Course[]> {
  return coursesData.courses
    .filter(course => course.category === category)
    .sort((a, b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime());
}

export async function getCourseById(id: string): Promise<Course | null> {
  return coursesData.courses.find(course => course.id === id) || null;
}