import lawsData from '../data/laws.json';
import type { Law } from '../types';

export async function getLatestLaws(limit = 10): Promise<Law[]> {
  return lawsData.laws
    .sort((a, b) => new Date(b.effectiveAt).getTime() - new Date(a.effectiveAt).getTime())
    .slice(0, limit);
}

export async function getLawById(id: string): Promise<Law | null> {
  return lawsData.laws.find(law => law.id === id) || null;
}

export async function getLawsByCategory(category: string): Promise<Law[]> {
  return lawsData.laws
    .filter(law => law.category === category)
    .sort((a, b) => new Date(b.effectiveAt).getTime() - new Date(a.effectiveAt).getTime());
}