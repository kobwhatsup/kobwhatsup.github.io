export const deployConfig = {
  github: {
    username: 'kobwhatsup',
    repository: '-',
    branch: 'gh-pages',
    cname: ''
  },
  
  build: {
    outDir: 'dist',
    assets: 'assets'
  }
};