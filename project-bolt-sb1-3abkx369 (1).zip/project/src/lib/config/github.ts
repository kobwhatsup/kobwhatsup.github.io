export const githubConfig = {
  username: 'kobwhatsup',
  repository: 'kobwhatsup.github.io',
  branch: 'main',
  url: 'https://kobwhatsup.github.io'
};