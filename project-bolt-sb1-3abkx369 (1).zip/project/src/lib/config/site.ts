export const siteConfig = {
  name: '金牌调解员',
  description: '专业的调解员服务平台',
  url: 'https://mediator-platform.netlify.app',
  ogImage: 'https://mediator-platform.netlify.app/og.jpg',
  links: {
    github: 'https://github.com/mediator-platform',
    twitter: 'https://twitter.com/mediator_platform'
  }
}