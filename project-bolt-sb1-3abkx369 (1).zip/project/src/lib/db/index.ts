import { comments } from './comments';
import { posts } from './posts';
import { laws } from './laws';
import { articles } from './articles';
import { cases } from './cases';
import { courses } from './courses';

export {
  comments,
  posts,
  laws,
  articles,
  cases,
  courses
};