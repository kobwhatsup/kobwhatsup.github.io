import { db } from './client';

export async function getAllPosts() {
  const posts = await db.all(`
    SELECT 
      p.*,
      u.name as author_name,
      (SELECT COUNT(*) FROM comments c WHERE c.post_id = p.id) as comment_count
    FROM posts p
    LEFT JOIN users u ON p.author_id = u.id
    ORDER BY p.created_at DESC
  `);

  return posts.map(post => ({
    ...post,
    author: { name: post.author_name },
    _count: { comments: post.comment_count }
  }));
}

export async function getPostById(id: string) {
  const post = await db.get(`
    SELECT 
      p.*,
      u.name as author_name
    FROM posts p
    LEFT JOIN users u ON p.author_id = u.id
    WHERE p.id = ?
  `, [id]);

  if (!post) return null;

  return {
    ...post,
    author: { name: post.author_name }
  };
}

export async function createPost(data: {
  title: string;
  content: string;
  category: string;
  authorId: string;
}) {
  const id = crypto.randomUUID();
  await db.run(`
    INSERT INTO posts (id, title, content, category, author_id)
    VALUES (?, ?, ?, ?, ?)
  `, [id, data.title, data.content, data.category, data.authorId]);
  return id;
}