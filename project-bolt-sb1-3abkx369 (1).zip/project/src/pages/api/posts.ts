import type { APIRoute } from 'astro';
import { createPost } from '../../lib/db/posts';

export const POST: APIRoute = async ({ request }) => {
  try {
    const formData = await request.formData();
    const title = formData.get('title') as string;
    const content = formData.get('content') as string;
    const category = formData.get('category') as string;
    
    // TODO: 从会话中获取用户ID
    const authorId = 'test-user';

    const postId = await createPost({
      title,
      content,
      category,
      authorId
    });

    return new Response(null, {
      status: 302,
      headers: {
        'Location': `/forum/${postId}`
      }
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: 'Failed to create post' }), {
      status: 500,
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }
};